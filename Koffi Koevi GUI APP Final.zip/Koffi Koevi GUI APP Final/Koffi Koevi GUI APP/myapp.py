from flask import Flask, render_template, request, redirect, url_for

import sqlite3

import os

app=Flask(__name__,template_folder='templates')

currentdirectory  = os.path.dirname(os.path.abspath(__file__))



app = Flask(__name__)

@app.route('/')
def main():
    return render_template('clientMenu.html')

@app.route('/register')
def register():
    return render_template('insert.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/addphonecall')
def addPhoneCall():
    return render_template('addphonecall.html')

@app.route('/updatephonecall')
def updatePhoneCall():
    return render_template('updatephonecall.html')

@app.route('/deletephonecall')
def deletePhoneCall():
    return render_template('deletephonecall.html')

@app.route('/updatePC', methods = ["POST", "GET"])
def updatePC():
    if request.method == "POST":
        pc_id = request.form['pc_id']
        caller = request.form['caller']
        callee = request.form['callee']
        start = request.form['start']
        end = request.form['end']

        # connection to the database
        connection = sqlite3.connect('/Users/awadagbe/Desktop/Jeremiah/phonebook.db')
        cursor = connection.cursor()
        
        #Update phone call
        query001 = "UPDATE phoneCall SET caller = '{clr}',  callee = '{cle}', start = '{stt}', end = '{ed}'   WHERE phonecall_id = '{c_id}'".format(c_id = pc_id, clr = caller, cle = callee, stt = start, ed=end)
        cursor.execute(query001)
        connection.commit()
        return render_template('operationMenu.html')

@app.route('/deletePC', methods = ["POST", "GET"])
def deletePC():
    if request.method == "POST":
        pc_id = request.form['pc_id']
       
        # connection to the database
        connection = sqlite3.connect('/Users/awadagbe/Desktop/Jeremiah/phonebook.db')
        cursor = connection.cursor()
        
        #Delete phone call
        query002 = "DELETE FROM phoneCall WHERE phonecall_id = '{c_id}'".format(c_id = pc_id)
        cursor.execute(query002)
        connection.commit()
        return render_template('operationMenu.html')


@app.route('/viewPhoneCall', methods = ["POST", "GET"])
def viewPhoneCall():
    if request.method == "POST":
        call_id = request.form['phonecall_id']

        # connection to the database
        connection = sqlite3.connect('/Users/awadagbe/Desktop/Jeremiah/phonebook.db')
        cursor = connection.cursor()
        
        #Test if client already exist
        query00 = "SELECT * FROM phoneCall WHERE phonecall_id = '{c_id}'".format(c_id = call_id)
        cursor.execute(query00)
        reqrow = cursor.fetchone()

        phC_id = reqrow[0]
        caller = reqrow[1]
        callee = reqrow[1]
        start = reqrow[3]
        end = reqrow[4]
        return render_template('viewPhoneCall.html', phC_id = phC_id, caller = caller, callee =callee, start = start, end =end)
        # return render_template('viewPhoneCall.html', caller = caller, callee = callee, start = start, end = end )

@app.route('/viewdelete', methods = ["POST", "GET"])
def viewdelete():
    if request.method == "POST":
        call_id = request.form['phonecall_id']

        # connection to the database
        connection = sqlite3.connect('/Users/awadagbe/Desktop/Jeremiah/phonebook.db')
        cursor = connection.cursor()
        
        #Test if client already exist
        query00 = "SELECT * FROM phoneCall WHERE phonecall_id = '{c_id}'".format(c_id = call_id)
        cursor.execute(query00)
        reqrow = cursor.fetchone()

        phC_id = reqrow[0]
        caller = reqrow[1]
        callee = reqrow[1]
        start = reqrow[3]
        end = reqrow[4]
        return render_template('viewdelete.html', phC_id = phC_id, caller = caller, callee =callee, start = start, end =end)

@app.route('/insert', methods = ["POST", "GET"])
def insertClient():
    if request.method == "POST":
        clientname = request.form['username']
        pwd = request.form['pwd']
        
        # connection to the database
        connection = sqlite3.connect('/Users/awadagbe/Desktop/Jeremiah/phonebook.db')
        cursor = connection.cursor()
        
        #Test if client already exist
        query0 = "SELECT COUNT(*) FROM client WHERE username = '{usn}' AND password = '{upwd}'".format(usn = clientname, upwd = pwd)
        cursor.execute(query0)
        nb_row = cursor.fetchone()
        print("Number of rows: ", nb_row[0])
        
        # Register client
        if nb_row[0] < 1 :
            query1 = "INSERT INTO client(username, password) VALUES('{usern}', '{userpwd}')".format(usern = clientname, userpwd = pwd)
            cursor.execute(query1)
            connection.commit()
            return render_template('regSuccess.html')
        else:
            return render_template('clientExist.html')


@app.route('/loginsucced', methods = ["POST", "GET"])
def loginSucced():
    if request.method == "POST":
        clientname = request.form['username']
        pwd = request.form['pwd']
        
        # connection to the database
        connection = sqlite3.connect('/Users/awadagbe/Desktop/Jeremiah/phonebook.db')
        cursor = connection.cursor()
        
        #Test if client already exist
        query0 = "SELECT COUNT(*) FROM client WHERE username = '{usn}' AND password = '{upwd}'".format(usn = clientname, upwd = pwd)
        cursor.execute(query0)
        nb_row = cursor.fetchone()
        print("Number of rows: ", nb_row[0])
        
        # Login 
        if nb_row[0] >= 1 :
            return render_template('operationMenu.html')
        else:
            return render_template('loginfailed.html')

@app.route('/addinfocall', methods = ["POST", "GET"])
def addInfoCall():
    if request.method == "POST":
        caller = request.form['caller']
        callee = request.form['callee']
        start = request.form['start']
        end = request.form['end']
        
        # connection to the database
        connection = sqlite3.connect('/Users/awadagbe/Desktop/Jeremiah/phonebook.db')
        cursor = connection.cursor()
        
        # Add phone call
        query2 = "INSERT INTO phoneCall(caller, callee, start, end) VALUES('{pcaller}', '{pcallee}', '{pstart}', '{pend}')".format(pcaller = caller, pcallee = callee, pstart = start, pend = end)
        cursor.execute(query2)
        connection.commit()
        return render_template('operationMenu.html')
        

if __name__ == "__main__":
    app.debug = True
    app.run()